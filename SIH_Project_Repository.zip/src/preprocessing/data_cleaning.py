import pandas as pd

def clean_text(text):
    return text.lower()

def calculate_score(novelty, impact, roi):
    return (novelty * 0.4) + (impact * 0.3) + (roi * 0.3)

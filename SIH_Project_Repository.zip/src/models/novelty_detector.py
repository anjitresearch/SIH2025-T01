def detect_novelty(text):
    return {'novelty_score': 0.85}

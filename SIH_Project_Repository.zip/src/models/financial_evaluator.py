def evaluate_financials(data):
    return {'roi': 1.5, 'cost_efficiency': 'High'}

def explain_score(score):
    return f'Score of {score} explained by weighted factors.'

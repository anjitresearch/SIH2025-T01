## SIH Project

This project evaluates proposals based on novelty, financial feasibility, and societal impact.